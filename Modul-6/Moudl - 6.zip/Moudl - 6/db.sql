-- Buat Database
CREATE DATABASE IF NOT EXISTS penjualan_db;
USE penjualan_db;

-- 1. Tabel Pelanggan
CREATE TABLE IF NOT EXISTS pelanggan (
    id VARCHAR(20) PRIMARY KEY,
    nama_pelanggan VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('L', 'P') NOT NULL,
    telp VARCHAR(15) NOT NULL,
    alamat TEXT NOT NULL
);

-- 2. Tabel Supplier
CREATE TABLE IF NOT EXISTS supplier (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    telp VARCHAR(12) NOT NULL,
    alamat TEXT NOT NULL
);

-- 3. Tabel Barang (Relasi ke Supplier)
CREATE TABLE IF NOT EXISTS barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_barang VARCHAR(10) NOT NULL UNIQUE,
    nama_barang VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    stok INT NOT NULL,
    supplier_id INT NOT NULL,
    FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- 4. Tabel User (Admin/Petugas)
CREATE TABLE IF NOT EXISTS user (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL UNIQUE,
    password VARCHAR(35) NOT NULL,
    nama VARCHAR(50) NOT NULL,
    alamat VARCHAR(100) NOT NULL,
    telp VARCHAR(20) NOT NULL,
    level TINYINT(1) NOT NULL
);

-- 5. Tabel Transaksi (Master - Relasi ke Pelanggan)
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    waktu_transaksi DATE NOT NULL,
    keterangan TEXT NOT NULL,
    total INT NOT NULL,
    pelanggan_id VARCHAR(20) NOT NULL,
    FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- 6. Tabel Transaksi Detail (Detail - Relasi ke Transaksi & Barang)
CREATE TABLE IF NOT EXISTS transaksi_detail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaksi_id INT NOT NULL,
    barang_id INT NOT NULL,
    harga INT NOT NULL,
    qty INT NOT NULL,
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- 7. Tabel Pembayaran (Relasi ke Transaksi)
CREATE TABLE IF NOT EXISTS pembayaran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    waktu_bayar DATETIME NOT NULL,
    total INT NOT NULL,
    metode ENUM('TUNAI', 'TRANSFER', 'EDC') NOT NULL,
    transaksi_id INT NOT NULL,
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE ON UPDATE CASCADE
);


-- ==========================================
-- CONTOH DATA AWAL (SEED DATA)
-- ==========================================

-- Data Pelanggan (Minimal 5)
INSERT INTO pelanggan (id, nama_pelanggan, jenis_kelamin, telp, alamat) VALUES
('P001', 'Budi Santoso', 'L', '081234567890', 'Jl. Merdeka No. 10, Bangkalan'),
('P002', 'Siti Aminah', 'P', '081987654321', 'Jl. Trunojoyo No. 45, Madura'),
('P003', 'Ahmad Dani', 'L', '081122334455', 'Jl. Raya Kamal No. 12'),
('P004', 'Dewi Lestari', 'P', '085678901234', 'Jl. Demangan Baru No. 8'),
('P005', 'Joko Widodo', 'L', '087812345678', 'Jl. Telang Indah No. 3');

-- Data Supplier (Minimal 5)
INSERT INTO supplier (nama, telp, alamat) VALUES
('PT Sumber Makmur', '0315551234', 'Jl. Rajawali No. 15, Surabaya'),
('CV Jaya Abadi', '0318889988', 'Jl. Kembang Jepun No. 42, Surabaya'),
('UD Berkah Sentosa', '0321776655', 'Jl. Pahlawan No. 7, Gresik'),
('Toko Utama Elektronik', '0317778899', 'Jl. Tunjungan No. 88, Surabaya'),
('Grosir Maju Bersatu', '0314443322', 'Jl. Dupak Rukun No. 5, Surabaya');

-- Data Barang (Minimal 5)
INSERT INTO barang (kode_barang, nama_barang, harga, stok, supplier_id) VALUES
('B001', 'Laptop ASUS Vivobook', 7500000, 10, 4),
('B002', 'Mouse Wireless Logitech', 150000, 25, 1),
('B003', 'Keyboard Mechanical', 450000, 15, 2),
('B004', 'Monitor 24 Inch LG', 1850000, 8, 4),
('B005', 'Flashdisk 32GB SanDisk', 75000, 50, 3);

-- Data User (Admin)
INSERT INTO user (username, password, nama, alamat, telp, level) VALUES
('admin', '202cb962ac59075b964b07152d234b70', 'Administrator Utama', 'Bangkalan', '081234567899', 1);

-- 1. Masukkan 10 Data Transaksi (Master)
INSERT INTO transaksi (id, waktu_transaksi, keterangan, total, pelanggan_id) VALUES
(1, '2026-11-01', 'Pembelian keperluan kantor', 24500, 'P001'),
(2, '2026-11-01', 'Belanja aksesoris komputer', 130000, 'P002'),
(3, '2026-11-02', 'Pesanan perangkat gaming', 36500, 'P003'),
(4, '2026-11-02', 'Pembelian aksesoris harian', 19000, 'P004'),
(5, '2026-11-03', 'Belanja perlengkapan IT', 30000, 'P005'),
(6, '2026-11-03', 'Pembelian mouse dan keyboard', 28500, 'P001'),
(7, '2026-11-04', 'Pesanan monitor dan flashdisk', 33000, 'P002'),
(8, '2026-11-04', 'Pembelian flashdisk grosir', 26000, 'P003'),
(9, '2026-11-04', 'Belanja komponen laptop', 28000, 'P004'),
(10, '2026-11-05', 'Pembelian unit tambahan', 40000, 'P005');

-- 2. Masukkan Data Detailnya (Transaksi Detail)
-- Menghubungkan setiap transaksi di atas dengan barang yang dibeli
INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES
(1, 2, 150000, 1),
(1, 5, 75000, 1),
(2, 3, 450000, 1),
(3, 1, 7500000, 1),
(3, 2, 150000, 2),
(4, 5, 75000, 2),
(5, 4, 1850000, 1),
(6, 2, 150000, 1),
(6, 3, 450000, 1),
(7, 4, 1850000, 1),
(8, 5, 75000, 3),
(9, 2, 150000, 2),
(10, 3, 450000, 1);