<?php
include 'koneksi.php';

$pesan = "";
$tipe_alert = "";

// Cek apakah parameter ID barang tersedia di URL
if (isset($_GET['id'])) {
    $id_barang = $_GET['id'];

    // 1. Periksa apakah barang tersebut sudah dipakai pada tabel transaksi_detail (Sesuai Soal No. 3)
    $stmt_cek = $pdo->prepare("SELECT COUNT(*) FROM transaksi_detail WHERE barang_id = ?");
    $stmt_cek->execute([$id_barang]);
    $jumlah_pakai = $stmt_cek->fetchColumn();

    if ($jumlah_pakai > 0) {
        // Jika sudah dipakai, batalkan penghapusan dan berikan pesan notifikasi
        $pesan = "Gagal menghapus! Data barang masih digunakan pada transaksi dan tidak boleh dihapus.";
        $tipe_alert = "danger";
    } else {
        // Jika belum dipakai, lakukan proses hapus data barang seperti biasa
        $stmt_hapus = $pdo->prepare("DELETE FROM barang WHERE id = ?");
        $stmt_hapus->execute([$id_barang]);
        $pesan = "Data barang berhasil dihapus.";
        $tipe_alert = "success";
    }
} else {
    header("Location: barang.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hapus Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="card" style="max-width: 500px; margin: 50px auto; text-align: center;">
        <h3>Status Penghapusan Barang</h3>
        
        <p style="margin: 20px 0; color: <?= ($tipe_alert == 'danger') ? 'red' : 'green'; ?>; font-weight: bold;">
            <?= htmlspecialchars($pesan); ?>
        </p>

        <a href="barang.php" class="btn">Kembali ke Daftar Barang</a>
    </div>
</body>
</html>