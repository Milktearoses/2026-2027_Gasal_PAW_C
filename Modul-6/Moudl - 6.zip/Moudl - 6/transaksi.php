<?php
include 'koneksi.php';

$pesan = "";

// Proses simpan data master-detail saat form disubmit
if (isset($_POST['simpan'])) {
    $waktu_transaksi = $_POST['waktu_transaksi'];
    $keterangan = $_POST['keterangan'];
    $pelanggan_id = $_POST['pelanggan_id'];
    $barang_id_arr = $_POST['barang_id'];
    $qty_arr = $_POST['qty'];

    try {
        $pdo->beginTransaction();

        // 1. Insert ke tabel master (transaksi) dengan total awal 0
        $stmt = $pdo->prepare("INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES (?, ?, 0, ?)");
        $stmt->execute([$waktu_transaksi, $keterangan, $pelanggan_id]);
        $transaksi_id = $pdo->lastInsertId();

        $total_transaksi = 0;

        // 2. Insert ke tabel detail dan hitung total otomatis (Soal No. 4)
        for ($i = 0; $i < count($barang_id_arr); $i++) {
            $b_id = $barang_id_arr[$i];
            $q = $qty_arr[$i];

            if (!empty($b_id) && $q > 0) {
                // Ambil harga barang saat ini dari database
                $stmt_b = $pdo->prepare("SELECT harga FROM barang WHERE id = ?");
                $stmt_b->execute([$b_id]);
                $harga = $stmt_b->fetchColumn();

                $subtotal = $harga * $q;
                $total_transaksi += $subtotal;

                // Simpan ke tabel transaksi_detail
                $stmt_detail = $pdo->prepare("INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES (?, ?, ?, ?)");
                $stmt_detail->execute([$transaksi_id, $b_id, $harga, $q]);
            }
        }

        // 3. Update total pada tabel transaksi utama (Soal No. 4)
        $stmt_update = $pdo->prepare("UPDATE transaksi SET total = ? WHERE id = ?");
        $stmt_update->execute([$total_transaksi, $transaksi_id]);

        $pdo->commit();
        header("Location: index.php?pesan=sukses");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $pesan = "Gagal menyimpan transaksi: " . $e->getMessage();
    }
}

// Ambil data pelanggan dan barang untuk pilihan dropdown
$list_pelanggan = $pdo->query("SELECT * FROM pelanggan")->fetchAll(PDO::FETCH_ASSOC);
$list_barang = $pdo->query("SELECT * FROM barang")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Transaksi Master-Detail</title>
    <link rel="stylesheet" href="style.css">
    <script>
        // Fungsi JavaScript untuk menonaktifkan (disabled) barang yang sudah dipilih di baris lain (Soal No. 2)
        function updateDropdownOptions() {
            let selects = document.querySelectorAll('.barang-select');
            let selectedValues = [];

            // Kumpulkan semua value barang yang sudah dipilih di baris mana pun
            selects.forEach(select => {
                if (select.value) {
                    selectedValues.push(select.value);
                }
            });

            // Atur status option pada setiap select dropdown
            selects.forEach(select => {
                let options = select.querySelectorAll('option');
                options.forEach(option => {
                    if (option.value) {
                        // Jika sudah dipilih di baris lain dan bukan nilai dari select ini sendiri, disable
                        if (selectedValues.includes(option.value) && select.value !== option.value) {
                            option.disabled = true;
                        } else {
                            option.disabled = false;
                        }
                    }
                });
            });
        }

        // Fungsi untuk menambah baris detail barang secara dinamis
        function tambahBarisDetail() {
            let container = document.getElementById('detail-container');
            let firstRow = container.querySelector('.detail-row');
            let newRow = firstRow.cloneNode(true);

            // Reset nilai input pada baris baru
            newRow.querySelector('.barang-select').value = "";
            newRow.querySelector('input[name="qty[]"]').value = "1";

            container.appendChild(newRow);
            updateDropdownOptions();
        }

        // Fungsi untuk menghapus baris detail
        function hapusBaris(button) {
            let rows = document.querySelectorAll('.detail-row');
            if (rows.length > 1) {
                button.closest('.detail-row').remove();
                updateDropdownOptions();
            } else {
                alert("Minimal harus ada 1 barang dalam transaksi!");
            }
        }
    </script>
</head>
<body>

    <div class="card">
        <h2>Form Input Transaksi (Master-Detail)</h2>
        <a href="index.php" class="btn">&larr; Kembali ke Menu Utama</a>

        <?php if ($pesan): ?>
            <p style="color: red; margin-top: 10px;"><?= $pesan; ?></p>
        <?php endif; ?>

        <form method="POST" style="margin-top: 15px;">
            <!-- Bagian Master Transaksi -->
            <h3>Data Master Transaksi</h3>
            <div style="margin-bottom: 15px;">
                <label><strong>Tanggal Transaksi:</strong></label><br>
                <input type="date" name="waktu_transaksi" value="<?= date('Y-m-d'); ?>" required style="padding: 6px; width: 300px; margin-top: 5px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label><strong>Pelanggan:</strong></label><br>
                <select name="pelanggan_id" required style="padding: 6px; width: 300px; margin-top: 5px;">
                    <option value="">-- Pilih Pelanggan --</option>
                    <?php foreach ($list_pelanggan as $p): ?>
                        <option value="<?= $p['id']; ?>"><?= htmlspecialchars($p['nama_pelanggan']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="margin-bottom: 15px;">
                <label><strong>Keterangan:</strong></label><br>
                <textarea name="keterangan" rows="2" style="padding: 6px; width: 300px; margin-top: 5px;" placeholder="Catatan transaksi..."></textarea>
            </div>

            <hr style="margin: 20px 0;">

            <!-- Bagian Detail Transaksi -->
            <h3>Detail Barang Transaksi</h3>
            <div id="detail-container">
                <div class="detail-row" style="display: flex; gap: 10px; margin-bottom: 10px; align-items: center;">
                    <select name="barang_id[]" class="barang-select" required onchange="updateDropdownOptions()" style="padding: 6px; width: 350px;">
                        <option value="">-- Pilih Barang --</option>
                        <?php foreach ($list_barang as $b): ?>
                            <option value="<?= $b['id']; ?>"><?= htmlspecialchars($b['nama_barang']); ?> (Rp <?= number_format($b['harga'], 0, ',', '.'); ?> - Stok: <?= $b['stok']; ?>)</option>
                        <?php endforeach; ?>
                    </select>

                    <input type="number" name="qty[]" min="1" value="1" required style="padding: 6px; width: 80px;" placeholder="Qty">

                    <button type="button" class="btn btn-danger" onclick="hapusBaris(this)">Hapus</button>
                </div>
            </div>

            <button type="button" class="btn" onclick="tambahBarisDetail()" style="background-color: #0275d8; margin-top: 5px;">+ Tambah Baris Barang</button>
            
            <br><br>
            <hr style="margin: 20px 0;">
            <button type="submit" name="simpan" class="btn" style="background-color: #5cb85c; font-size: 15px; padding: 10px 20px; cursor: pointer;">Simpan Transaksi</button>
        </form>
    </div>

</body>
</html>