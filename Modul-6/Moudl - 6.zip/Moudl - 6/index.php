<?php
include 'koneksi.php';

// Ambil data master transaksi
$transaksi = $pdo->query("SELECT t.*, p.nama_pelanggan FROM transaksi t LEFT JOIN pelanggan p ON t.pelanggan_id = p.id ORDER BY t.id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Cek apakah ada parameter detail_id yang diklik
$detail_id = isset($_GET['detail_id']) ? $_GET['detail_id'] : null;
$detail_data = [];
$master_selected = null;

if ($detail_id) {
    // Ambil data master spesifik yang dipilih untuk info detail
    $stmt_m = $pdo->prepare("SELECT t.*, p.nama_pelanggan FROM transaksi t LEFT JOIN pelanggan p ON t.pelanggan_id = p.id WHERE t.id = ?");
    $stmt_m->execute([$detail_id]);
    $master_selected = $stmt_m->fetch(PDO::FETCH_ASSOC);

    // Ambil data anakan (transaksi_detail) berdasarkan ID transaksi
    $stmt_d = $pdo->prepare("SELECT td.*, b.nama_barang, b.kode_barang FROM transaksi_detail td LEFT JOIN barang b ON td.barang_id = b.id WHERE td.transaksi_id = ?");
    $stmt_d->execute([$detail_id]);
    $detail_data = $stmt_d->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Transaksi - Master Detail</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Tabel Master Transaksi -->
    <div class="card">
        <h2>Data Transaksi (Master)</h2>
        <a href="transaksi.php" class="btn">+ Tambah Transaksi</a>
        <a href="barang.php" class="btn">Kelola Data Barang</a>
        
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Tanggal</th>
                    <th>Pelanggan</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($transaksi as $t): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $t['id']; ?></td>
                    <td><?= $t['waktu_transaksi']; ?></td>
                    <td><?= htmlspecialchars($t['nama_pelanggan']); ?></td>
                    <td>Rp <?= number_format($t['total'], 0, ',', '.'); ?></td>
                    <td>
                        <a href="index.php?detail_id=<?= $t['id']; ?>" class="btn btn-detail">Detail</a>
                        <a href="edit.php?id=<?= $t['id']; ?>" class="btn btn-edit">Edit</a>
                        <a href="hapus.php?id=<?= $t['id']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus transaksi ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Tabel Anakan / Detail Transaksi (Hanya muncul jika tombol Detail diklik) -->
    <?php if ($detail_id && $master_selected): ?>
    <div class="card" id="bagian-detail">
        <h3>Detail Transaksi ID: <?= $master_selected['id']; ?></h3>
        <div class="info-text">
            <p><strong>Tanggal:</strong> <?= $master_selected['waktu_transaksi']; ?> | 
               <strong>Pelanggan:</strong> <?= htmlspecialchars($master_selected['nama_pelanggan']); ?> | 
               <strong>Keterangan:</strong> <?= htmlspecialchars($master_selected['keterangan']); ?></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Harga Satuan</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no_d = 1; 
                $grand_total = 0;
                foreach ($detail_data as $d): 
                    $subtotal = $d['harga'] * $d['qty'];
                    $grand_total += $subtotal;
                ?>
                <tr>
                    <td><?= $no_d++; ?></td>
                    <td><?= htmlspecialchars($d['kode_barang']); ?></td>
                    <td><?= htmlspecialchars($d['nama_barang']); ?></td>
                    <td>Rp <?= number_format($d['harga'], 0, ',', '.'); ?></td>
                    <td><?= $d['qty']; ?></td>
                    <td>Rp <?= number_format($subtotal, 0, ',', '.'); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($detail_data)): ?>
                <tr>
                    <td colspan="6" style="text-align: center;">Tidak ada detail barang untuk transaksi ini.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

</body>
</html>