<?php
include 'koneksi.php';

// Ambil semua data barang
$barang_list = $pdo->query("SELECT b.*, s.nama AS nama_supplier FROM barang b LEFT JOIN supplier s ON b.supplier_id = s.id ORDER BY b.id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Tangkap pesan notifikasi jika ada dari proses hapus
$pesan = isset($_GET['pesan']) ? $_GET['pesan'] : "";
$status = isset($_GET['status']) ? $_GET['status'] : "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Data Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="card">
        <h2>Manajemen Data Barang</h2>
        <a href="index.php" class="btn">&larr; Kembali ke Menu Utama</a>

        <?php if ($pesan): ?>
            <div style="padding: 10px; margin: 15px 0; background-color: <?= ($status == 'danger') ? '#f2dede' : '#dff0d8'; ?>; color: <?= ($status == 'danger') ? '#a94442' : '#3c763d'; ?>; border: 1px solid transparent; border-radius: 4px;">
                <?= htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Supplier</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($barang_list as $b): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($b['kode_barang']); ?></td>
                    <td><?= htmlspecialchars($b['nama_barang']); ?></td>
                    <td>Rp <?= number_format($b['harga'], 0, ',', '.'); ?></td>
                    <td><?= $b['stok']; ?></td>
                    <td><?= htmlspecialchars($b['nama_supplier']); ?></td>
                    <td>
                        <!-- Tombol Hapus memanggil file hapus_barang.php -->
                        <a href="hapus_barang.php?id=<?= $b['id']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus barang ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>